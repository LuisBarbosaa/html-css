function pontos() {
    let sangue = Number (document.getElementById("sangue").value)
    let kits = Number (document.getElementById("kits").value)
    let resultado = 20 * sangue + 
}